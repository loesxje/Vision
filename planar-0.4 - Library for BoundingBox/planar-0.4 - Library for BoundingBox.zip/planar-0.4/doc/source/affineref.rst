:class:`planar.Affine` -- 2D Affine Transforms
==============================================

.. index:: Affine, affine transform class

.. autoclass:: planar.Affine
	:members:

