:class:`planar.Polygon` -- Polygonal Shapes
===========================================

.. index:: Polygon, polygon class

.. autoclass:: planar.Polygon
	:members:
	:inherited-members:

