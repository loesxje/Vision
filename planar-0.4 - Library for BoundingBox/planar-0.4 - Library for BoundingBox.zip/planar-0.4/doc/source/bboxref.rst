:class:`planar.BoundingBox` -- Bounding Boxes
=============================================

.. index:: BoundingBox, bounding box class

.. autoclass:: planar.BoundingBox
	:members:

