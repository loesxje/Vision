:class:`planar.Vec2Array` -- 2D Vector Arrays
=============================================

.. index:: Vec2Array, Vector array class

.. autoclass:: planar.Vec2Array
	:members:
	:inherited-members:

.. index:: Seq2, Vector sequence base class

.. autoclass:: planar.Seq2
	:members:

